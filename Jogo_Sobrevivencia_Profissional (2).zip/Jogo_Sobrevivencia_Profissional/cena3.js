class Cena3 extends Phaser.Scene {
    constructor() {
        super({ key: 'Cena3' });
    }

    init(data) {
        this.pontuacaoFinal = data.pontuacao || 0;
        const recordeSalvo = localStorage.getItem('recorde') || 0;
        this.recorde = Math.max(this.pontuacaoFinal, recordeSalvo);
        if (this.pontuacaoFinal > recordeSalvo) {
            localStorage.setItem('recorde', this.pontuacaoFinal);
        }
    }

    preload() {
        this.load.image('fundogo', 'Assets/fundogo.png'); 
    }

    create() {
        const fundo = this.add.image(0, 0, 'fundogo');
        fundo.setOrigin(0, 0);
        fundo.setDisplaySize(this.sys.game.config.width, this.sys.game.config.height);

        const estilo = {
            fontFamily: 'Arial',
            fontSize: '36px',
            color: '#ffffff',
            stroke: '#000000',
            strokeThickness: 6,
            fontStyle: 'bold'
        };

        this.add.text(400, 100, 'FIM DE JOGO', {
            ...estilo,
            fontSize: '52px'
        }).setOrigin(0.5);

        this.add.text(400, 220, 'Pontuação: ' + this.pontuacaoFinal, estilo).setOrigin(0.5);
        this.add.text(400, 280, 'Recorde: ' + this.recorde, estilo).setOrigin(0.5);

        const botaoRecomecar = this.add.text(400, 400, 'RECOMEÇAR', estilo)
            .setOrigin(0.5)
            .setInteractive({ useHandCursor: true })
            .on('pointerdown', () => this.scene.start('Cena2'));

        botaoRecomecar.on('pointerover', () => botaoRecomecar.setStyle({ color: '#ff0000' }));
        botaoRecomecar.on('pointerout', () => botaoRecomecar.setStyle({ color: '#ffffff' }));
    }
}
