class Cena2 extends Phaser.Scene {
    constructor() {
        super({ key: 'Cena2' });
    }

    preload() {
        this.load.image('fundojogo', 'Assets/fundojogo.jpg');
        this.load.image('astro', 'Assets/astro.png');
        this.load.image('laser', 'Assets/lasers.png');
        this.load.image('foguete', 'Assets/foguetes.png');
        this.load.image('explosao1', 'Assets/explosão1.png');
        this.load.image('explosao2', 'Assets/explosão2.png');
        this.load.image('explosao3', 'Assets/explosão3.png');
        this.load.image('pausa', 'Assets/pausa.png');
        this.load.image('fogueteBtn', 'Assets/foguetes.png');
    }

    create() {
        this.add.image(400, 300, 'fundojogo').setDisplaySize(800, 600);

        this.player = this.physics.add.image(400, 520, 'astro')
            .setScale(0.2)
            .setCollideWorldBounds(true)
            .setSize(60, 80)
            .setOffset(20, 20);

        this.cursors = this.input.keyboard.createCursorKeys();
        this.obstaculos = this.physics.add.group();

        this.velocidadeObstaculo = 200;
        this.intervalo = 1000;

        this.tempo = this.time.addEvent({
            delay: this.intervalo,
            callback: this.criarObstaculo,
            callbackScope: this,
            loop: true
        });

        this.aumentarDificuldade = this.time.addEvent({
            delay: 5000,
            callback: () => {
                if (this.intervalo > 400) {
                    this.intervalo -= 50;
                    this.tempo.reset({ delay: this.intervalo, callback: this.criarObstaculo, callbackScope: this, loop: true });
                }
                this.velocidadeObstaculo += 10;
            },
            loop: true
        });

        this.pontuacao = parseInt(localStorage.getItem('pontuacao')) || 0;
        this.textoPontuacao = this.add.text(20, 20, 'Pontuação: ' + this.pontuacao, {
            fontFamily: 'Arial',
            fontSize: '28px',
            color: '#ffffff',
            stroke: '#000000',
            strokeThickness: 4
        });

        this.botaoPausa = this.add.image(770, 30, 'pausa')
            .setScale(0.08)
            .setInteractive()
            .setScrollFactor(0)
            .setDepth(1001);

        this.ecrãPausa = this.add.rectangle(400, 300, 800, 600, 0x000000, 0.6)
            .setVisible(false)
            .setDepth(1000);

        this.textoPausa = this.add.text(400, 200, 'PAUSADO', {
            fontFamily: 'Arial',
            fontSize: '48px',
            color: '#ffffff'
        }).setOrigin(0.5)
            .setVisible(false)
            .setDepth(1001);

        const estiloTexto = {
            fontFamily: 'Arial',
            fontSize: '20px',
            color: '#ffffff',
            fontStyle: 'bold',
            stroke: '#000000',
            strokeThickness: 4
        };

        this.fogueteMenu = this.add.image(400, 300, 'fogueteBtn')
            .setScale(0.15)
            .setAngle(-90)
            .setInteractive({ useHandCursor: true })
            .setVisible(false)
            .setDepth(1001)
            .on('pointerover', () => this.fogueteMenu.setScale(0.17))
            .on('pointerout', () => this.fogueteMenu.setScale(0.15))
            .on('pointerdown', () => this.scene.start('Cena1'));

        this.textoBotaoMenu = this.add.text(400, 370, 'VOLTAR AO MENU', estiloTexto)
            .setOrigin(0.5)
            .setVisible(false)
            .setDepth(1001);

        this.botaoPausa.on('pointerdown', () => {
            const pausado = this.physics.world.isPaused;
            if (pausado) {
                this.physics.resume();
                this.tempo.paused = false;
                this.ecrãPausa.setVisible(false);
                this.textoPausa.setVisible(false);
                this.fogueteMenu.setVisible(false);
                this.textoBotaoMenu.setVisible(false);
            } else {
                this.physics.pause();
                this.tempo.paused = true;
                this.ecrãPausa.setVisible(true);
                this.textoPausa.setVisible(true);
                this.fogueteMenu.setVisible(true);
                this.textoBotaoMenu.setVisible(true);
            }
        });
    }

    update() {
        if (this.physics.world.isPaused) return;

        if (this.cursors.left.isDown) {
            this.player.setVelocityX(-250);
        } else if (this.cursors.right.isDown) {
            this.player.setVelocityX(250);
        } else {
            this.player.setVelocityX(0);
        }

        this.pontuacao++;
        this.textoPontuacao.setText('Pontuação: ' + this.pontuacao);
        localStorage.setItem('pontuacao', this.pontuacao);

        const playerBounds = this.player.getBounds();
        this.obstaculos.getChildren().forEach(obst => {
            if (Phaser.Geom.Intersects.RectangleToRectangle(playerBounds, obst.getBounds())) {
                this.fimDeJogo(this.player, obst);
            }
        });
    }

    criarObstaculo() {
        const x = Phaser.Math.Between(50, 750);
        const tipo = Phaser.Math.Between(0, 1);
        const sprite = tipo === 0 ? 'laser' : 'foguete';
        const velocidade = this.velocidadeObstaculo + Phaser.Math.Between(0, 50);
        const escala = tipo === 0 ? 0.15 : 0.12;

        let podeCriar = true;
        this.obstaculos.getChildren().forEach(obst => {
            if (Phaser.Math.Distance.Between(obst.x, obst.y, x, -50) < 100) {
                podeCriar = false;
            }
        });

        if (!podeCriar) return;

        const obst = this.obstaculos.create(x, -50, sprite)
            .setVelocityY(velocidade)
            .setScale(escala)
            .setSize(40, 100)
            .setOffset(10, 10);

        if (tipo === 1) {
            obst.setAngle(135);
        }
    }

    fimDeJogo(jogador, obstaculo) {
        const efeitos = ['explosao1', 'explosao2', 'explosao3'];
        const efeito = Phaser.Utils.Array.GetRandom(efeitos);

        this.add.image(jogador.x, jogador.y, efeito).setScale(0.2);
        jogador.setVisible(false);
        this.physics.pause();

        localStorage.removeItem('pontuacao');

        this.time.delayedCall(1000, () => {
            this.scene.start('Cena3', { pontuacao: this.pontuacao });
        });
    }
}
