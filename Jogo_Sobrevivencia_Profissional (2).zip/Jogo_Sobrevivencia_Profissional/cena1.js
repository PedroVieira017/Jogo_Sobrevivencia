class Cena1 extends Phaser.Scene {
    constructor() {
        super({ key: 'Cena1' });
    }

    preload() {
        this.load.image('fundoMenu', 'Assets/fundomenu.jpg');
        this.load.image('fogueteBtn', 'Assets/foguetes.png');
    }

    create() {
        this.add.image(400, 300, 'fundoMenu').setDisplaySize(800, 600);

        const estiloTexto = {
            fontFamily: 'Arial',
            fontSize: '20px',
            color: '#ffffff',
            fontStyle: 'bold',
            stroke: '#000000',
            strokeThickness: 4
        };

        // Botão "Novo Jogo"
        const botaoNovo = this.add.image(130, 200, 'fogueteBtn')
            .setScale(0.15)
            .setAngle(-90)
            .setInteractive({ useHandCursor: true })
            .on('pointerover', () => botaoNovo.setScale(0.17))
            .on('pointerout', () => botaoNovo.setScale(0.15))
            .on('pointerdown', () => {
                localStorage.removeItem('pontuacao');
                this.scene.start('Cena2');
            });

        this.add.text(130, 270, 'NOVO JOGO', estiloTexto).setOrigin(0.5);

        // Botão "Continuar"
        const botaoCont = this.add.image(130, 350, 'fogueteBtn')
            .setScale(0.15)
            .setAngle(-90)
            .setInteractive({ useHandCursor: true })
            .on('pointerover', () => botaoCont.setScale(0.17))
            .on('pointerout', () => botaoCont.setScale(0.15))
            .on('pointerdown', () => {
                if (localStorage.getItem('pontuacao')) {
                    this.scene.start('Cena2');
                }
            });

        this.add.text(130, 420, 'CONTINUAR', estiloTexto).setOrigin(0.5);
    }
}
